
function getSelectFile() {
  var fileName = document.getElementById("fileSelect").value;
  document.getElementById("executFileName").value = fileName;
  console.log("Select File:%s", fileName);
}

function getSelectPath() {
  document.querySelector('#b').addEventListener('change', e => {
    for (let entry of e.target.files) {
      console.log(entry.name, entry.webkitRelativePath);
      document.getElementById("path1").value = entry.webkitRelativePath
      break;
    }
  });
}

function checkClient() {
}

function getDestPath(){
  var pathName = document.getElementById("pathId").value;
  console.log(pathName)
  alert(pathName)
}

window.onload = function () {
  // var x = "SelectFile", b;
  // (b = document.createElement("button")).innerHTML = "选择文件 Test";
  // b.setAttribute("onclick", "alert('" + x + "')");
  // document.body.appendChild(b);
}

function startSliceTask(sliceCount) {
  // onclick="window.location.href='MediaFileProcess://slice'"
  if (sliceCount <= 1) {
    alert("分块数量至少大于 2");
    console.log("分块数量至少大于 2，" + " current slice count:" + sliceCount);
    return;
  }
  var s = "MediaFileProcess://slice ";
  s = s + sliceCount;
  console.log(s);
  window.location.href=s;
}
